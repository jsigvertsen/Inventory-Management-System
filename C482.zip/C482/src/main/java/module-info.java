module sigvertsen.c482 {
    requires javafx.controls;
    requires javafx.fxml;


    opens sigvertsen.c482 to javafx.fxml;
    exports sigvertsen.c482;
    exports sigvertsen.c482.controller;
    exports sigvertsen.c482.model;
    opens sigvertsen.c482.controller to javafx.fxml;
    opens sigvertsen.c482.model to javafx.base;
}